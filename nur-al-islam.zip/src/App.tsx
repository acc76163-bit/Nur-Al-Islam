import React, { useState, useEffect, createContext, useContext } from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate, useLocation, useParams, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Book, 
  MessageSquare, 
  Clock, 
  Heart, 
  Settings as SettingsIcon,
  Moon,
  Sun,
  ChevronLeft,
  Play,
  Pause,
  Info,
  User as UserIcon,
  LogOut,
  Mail
} from 'lucide-react';

// Firebase
import { 
  auth, 
  db, 
  googleProvider, 
  handleFirestoreError, 
  OperationType 
} from './lib/firebase';
import { 
  signInWithPopup, 
  onAuthStateChanged, 
  signOut, 
  User as FirebaseUser 
} from 'firebase/auth';
import { 
  doc, 
  setDoc, 
  getDoc, 
  collection, 
  query, 
  orderBy, 
  getDocs, 
  serverTimestamp,
  addDoc 
} from 'firebase/firestore';

// Services
import { getAllSurahs, getSurahDetail, getAudioUrl, Surah, SurahDetail, Ayah, DUAS } from './services/quranService';
import { fetchPrayerTimes, PrayerTimes } from './services/prayerService';
import { chatWithImad } from './services/geminiService';
import { cn } from './lib/utils';

// --- Context ---

interface AuthContextType {
  user: FirebaseUser | null;
  loading: boolean;
  signIn: () => Promise<void>;
  logOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        // Sync user profile to Firestore
        const userRef = doc(db, 'users', u.uid);
        try {
          await setDoc(userRef, {
            displayName: u.displayName,
            email: u.email,
            photoURL: u.photoURL,
            lastLogin: serverTimestamp(),
            createdAt: serverTimestamp(), // Will only set if not existing due to merge in real apps, but here we can just set it
          }, { merge: true });
        } catch (err) {
          handleFirestoreError(err, OperationType.WRITE, `users/${u.uid}`);
        }
      }
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  const signIn = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      console.error("Login failed:", err);
    }
  };

  const logOut = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error("Logout failed:", err);
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, signIn, logOut }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within AuthProvider");
  return context;
};

// --- Components ---

const SplashScreen = ({ onFinish }: { onFinish: () => void }) => {
  return (
    <motion.div 
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8, ease: "easeInOut" }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-orange-600 text-white"
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1.2, ease: "easeOut" }}
        className="flex flex-col items-center"
      >
        <div className="w-28 h-28 mb-6 bg-white rounded-[32px] flex items-center justify-center shadow-2xl">
          <Heart className="w-16 h-16 text-orange-600 fill-orange-600" />
        </div>
        <h1 className="text-3xl font-bold tracking-tight">Nur Al-Islam</h1>
        <p className="mt-2 text-orange-100 opacity-80 font-medium">De weg naar vrede</p>
      </motion.div>
      <motion.div 
        className="absolute bottom-12"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        <div className="w-6 h-6 border-2 border-orange-200 border-t-white rounded-full animate-spin"></div>
      </motion.div>
    </motion.div>
  );
};

const NavBar = () => {
  const location = useLocation();

  const navItems = [
    { path: '/', icon: Clock, label: 'Gebed' },
    { path: '/quran', icon: Book, label: 'Koran' },
    { path: '/chat', icon: MessageSquare, label: 'Imad' },
    { path: '/dua', icon: Heart, label: 'Dua' },
    { path: '/settings', icon: SettingsIcon, label: 'Instellingen' },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[100] px-4 pb-8 pt-4 ios-blur border-t border-slate-200/50 dark:border-slate-800/50 bg-white/70 dark:bg-slate-900/70">
      <div className="max-w-md mx-auto flex justify-between items-center relative z-[101]">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path || (item.path !== '/' && location.pathname.startsWith(item.path));
          return (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "flex flex-col items-center gap-1 transition-all duration-300 ios-button cursor-pointer",
                isActive ? "text-orange-600 dark:text-orange-500 scale-110" : "text-slate-400 dark:text-slate-500"
              )}
            >
              <item.icon size={22} strokeWidth={isActive ? 2.5 : 2} />
              <span className="text-[10px] font-semibold leading-none mt-1">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
};

const PageWrapper = ({ children, title, backPath }: { children: React.ReactNode, title?: string, backPath?: string }) => {
  const navigate = useNavigate();
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="pb-32 pt-2 px-4 max-w-md mx-auto min-h-screen"
    >
      <div className="flex items-center justify-between mb-8">
        {backPath ? (
          <button onClick={() => navigate(backPath)} className="p-2 -ml-2 ios-button">
            <ChevronLeft size={28} />
          </button>
        ) : <div className="w-10"></div>}
        
        <h1 className="text-xl font-bold text-center">{title}</h1>
        
        <div className="w-10"></div>
      </div>
      {children}
    </motion.div>
  );
};

// --- Views ---

const Dashboard = () => {
  const [times] = useState<PrayerTimes>({
    Fajr: "04:06",
    Sunrise: "06:22",
    Dhuhr: "13:40",
    Asr: "17:30",
    Maghrib: "20:55",
    Isha: "22:42",
    Imsak: "03:56",
    Midnight: "00:00",
    Sunset: "20:55"
  });
  const [loading, setLoading] = useState(true);
  const [nextPrayer, setNextPrayer] = useState<{ label: string, time: string } | null>(null);

  useEffect(() => {
    const updateNextPrayer = () => {
      const now = new Date();
      const currentMinutes = now.getHours() * 60 + now.getMinutes();
      
      const prayerList = [
        { label: "Fajr", time: "04:06" },
        { label: "Dhuhr", time: "13:40" },
        { label: "Asr", time: "17:30" },
        { label: "Maghrib", time: "20:55" },
        { label: "Isha", time: "22:42" }
      ];

      const next = prayerList.find(p => {
        const [h, m] = p.time.split(':').map(Number);
        return (h * 60 + m) > currentMinutes;
      }) || prayerList[0];

      setNextPrayer(next);
      setLoading(false);
    };

    updateNextPrayer();
    const interval = setInterval(updateNextPrayer, 60000);
    return () => clearInterval(interval);
  }, []);

  if (loading) return (
    <div className="flex flex-col items-center justify-center h-[70vh] space-y-4">
      <div className="animate-spin text-orange-600 w-12 h-12 border-4 border-current border-t-transparent rounded-full shadow-lg shadow-orange-100" />
      <p className="text-slate-400 font-medium animate-pulse">Laden...</p>
    </div>
  );

  return (
    <PageWrapper title="Vandaag">
      <div className="space-y-6">
        <div className="ios-card p-6 bg-gradient-to-br from-orange-500 to-amber-600 text-white border-0 rounded-[38px] shadow-2xl shadow-orange-200 dark:shadow-none relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-20 group-hover:scale-110 transition-transform">
             <Clock size={80} />
          </div>
          <div className="flex justify-between items-start mb-6 relative z-10">
            <div>
              <p className="text-orange-100/90 text-xs font-bold uppercase tracking-widest mb-1">Volgende Gebed</p>
              <h2 className="text-4xl font-black tracking-tight">{nextPrayer?.label || "Fajr"}</h2>
            </div>
            <div className="text-right">
              <p className="text-orange-100/90 text-xs font-bold uppercase tracking-widest mb-1">Tijd</p>
              <h2 className="text-4xl font-black tracking-tight">{nextPrayer?.time || "--:--"}</h2>
            </div>
          </div>
          <div className="h-3 bg-white/20 rounded-full overflow-hidden relative z-10 p-0.5">
            <motion.div 
               initial={{ width: 0 }}
               animate={{ width: "72%" }}
               transition={{ duration: 1.5, ease: "easeOut" }}
               className="h-full bg-white rounded-full shadow-[0_0_15px_rgba(255,255,255,1)]" 
            />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4">
           {[
             { label: "Fajr (Ochtend)", value: "04:06", range: "04:06 — 04:20" },
             { label: "Shorooq (Opkomst)", value: "06:22", range: "06:22 — 06:34" },
             { label: "Dhuhr (Middag)", value: "13:40", range: "13:40 — 13:42" },
             { label: "Asr (Namiddag)", value: "17:30", range: "17:30 — 17:40" },
             { label: "Maghrib (Avond)", value: "20:55", range: "20:55 — 20:59" },
             { label: "Isha (Nacht)", value: "22:42", range: "22:42 — 23:05" }
           ].map((item) => (
             <div key={item.label} className="ios-card p-5 flex justify-between items-center rounded-[28px] bg-white dark:bg-slate-800 shadow-sm border-none transition-transform active:scale-[0.98]">
               <div className="flex flex-col gap-1">
                 <span className="font-bold text-slate-800 dark:text-slate-100 text-lg">{item.label}</span>
                 <div className="flex items-center gap-2">
                    <span className="text-[10px] text-orange-600 font-black uppercase tracking-widest bg-orange-50 dark:bg-orange-950/30 px-3 py-1 rounded-full">{item.range}</span>
                 </div>
               </div>
               <div className="text-right">
                 <span className="font-black text-2xl text-slate-900 dark:text-white">{item.value}</span>
               </div>
             </div>
           ))}
        </div>
      </div>
    </PageWrapper>
  );
};

const QuranList = () => {
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    getAllSurahs().then(setSurahs);
  }, []);

  return (
    <PageWrapper title="Koran">
      <div className="space-y-3">
        {surahs.map((surah) => (
          <button 
            key={surah.number}
            onClick={() => navigate(`/quran/${surah.number}`)}
            className="w-full ios-card p-4 flex items-center gap-4 text-left ios-button rounded-2xl"
          >
            <div className="w-10 h-10 rounded-full bg-orange-50 dark:bg-orange-900/20 flex items-center justify-center text-orange-600 font-bold shrink-0">
              {surah.number}
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-bold truncate">{surah.englishName}</h4>
              <p className="text-xs text-slate-500 truncate">{surah.englishNameTranslation}</p>
            </div>
            <div className="text-right">
              <p className="font-arabic text-xl leading-none font-bold text-orange-600 dark:text-orange-500">{surah.name}</p>
              <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-wider">{surah.numberOfAyahs} ayahs</p>
            </div>
          </button>
        ))}
      </div>
    </PageWrapper>
  );
};

const QuranReader = ({ id }: { id: string }) => {
  const [surah, setSurah] = useState<SurahDetail | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audio] = useState(new Audio());
  const [playbackRate, setPlaybackRate] = useState(1);

  useEffect(() => {
    getSurahDetail(parseInt(id)).then(setSurah);
    audio.src = getAudioUrl(parseInt(id));
    
    return () => {
      audio.pause();
    };
  }, [id, audio]);

  useEffect(() => {
    audio.playbackRate = playbackRate;
  }, [playbackRate, audio]);

  const toggleAudio = () => {
    if (isPlaying) audio.pause();
    else audio.play();
    setIsPlaying(!isPlaying);
  };

  if (!surah) return null;

  return (
    <PageWrapper title={surah.englishName} backPath="/quran">
      <div className="fixed top-20 left-0 right-0 z-30 px-4">
        <div className="max-w-md mx-auto ios-blur rounded-3xl p-4 border border-slate-200/50 dark:border-slate-800/50 shadow-xl flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={toggleAudio}
              className="w-12 h-12 bg-orange-600 text-white rounded-full flex items-center justify-center shadow-lg ios-button"
            >
              {isPlaying ? <Pause size={24} fill="currentColor" /> : <Play size={24} fill="currentColor" className="ml-1" />}
            </button>
            <div>
               <p className="text-[10px] uppercase tracking-widest text-slate-500">Recitatie</p>
               <p className="font-bold text-sm">Mishary Rashid Alafasy</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {[1, 1.5, 2].map(rate => (
              <button 
                key={rate}
                onClick={() => setPlaybackRate(rate)}
                className={cn(
                  "px-2 py-1 rounded-xl text-xs font-bold border transition-all",
                  playbackRate === rate 
                    ? "bg-orange-600 border-orange-600 text-white shadow-md shadow-orange-200 dark:shadow-none" 
                    : "border-slate-200 dark:border-slate-700 text-slate-500"
                )}
              >
                {rate}x
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-24 space-y-8 bg-white dark:bg-slate-800 p-8 rounded-[40px] shadow-sm">
        <div className="text-center py-4">
          <p className="font-arabic text-4xl text-orange-600 dark:text-orange-500 leading-relaxed mb-4">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</p>
        </div>
        {surah.ayahs.map((ayah) => (
          <div key={ayah.number} className="space-y-4 border-b border-slate-100 dark:border-slate-700/50 pb-6 last:border-0">
            <div className="flex justify-between items-start gap-4">
              <span className="w-8 h-8 rounded-full border border-orange-100 dark:border-orange-900/50 flex items-center justify-center text-[10px] font-bold text-orange-600 shrink-0">
                {ayah.numberInSurah}
              </span>
              <p className="font-arabic text-3xl text-right leading-loose flex-1" dir="rtl">
                {ayah.text}
              </p>
            </div>
          </div>
        ))}
      </div>
    </PageWrapper>
  );
};

const ImadChat = ({ messages, setMessages }: { messages: {role: 'user' | 'model', content: string}[], setMessages: React.Dispatch<React.SetStateAction<{role: 'user' | 'model', content: string}[]>> }) => {
  const { user } = useAuth();
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  // Load history from Firestore if logged in
  useEffect(() => {
    if (user) {
      const loadHistory = async () => {
        const q = query(
          collection(db, 'users', user.uid, 'chatHistory'),
          orderBy('timestamp', 'asc')
        );
        try {
          const snapshot = await getDocs(q);
          if (!snapshot.empty) {
            const hist = snapshot.docs.map(doc => ({
              role: doc.data().role as 'user' | 'model',
              content: doc.data().content as string
            }));
            setMessages(prev => {
              // Only update if current history is empty or different
              if (prev.length <= 1) return [prev[0], ...hist];
              return prev;
            });
          }
        } catch (err) {
          handleFirestoreError(err, OperationType.LIST, `users/${user.uid}/chatHistory`);
        }
      };
      loadHistory();
    }
  }, [user]);

  const sendMessage = async () => {
    if (!input.trim() || isTyping) return;
    
    const userPrompt = input.trim();
    const newUserMsg = { role: 'user' as const, content: userPrompt };
    const currentMessages = [...messages, newUserMsg];
    
    setMessages(currentMessages);
    setInput('');
    setIsTyping(true);

    // Sync user message to Firestore
    if (user) {
      try {
        await addDoc(collection(db, 'users', user.uid, 'chatHistory'), {
          ...newUserMsg,
          timestamp: serverTimestamp()
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `users/${user.uid}/chatHistory`);
      }
    }

    try {
      const historyForAI = currentMessages.slice(0, -1).map(m => ({ 
        role: m.role, 
        parts: [{ text: m.content }] 
      }));
      const response = await chatWithImad(userPrompt, historyForAI);
      const modelMsg = { role: 'model' as const, content: response };
      setMessages(prev => [...prev, modelMsg]);

      // Sync model response to Firestore
      if (user) {
        try {
          await addDoc(collection(db, 'users', user.uid, 'chatHistory'), {
            ...modelMsg,
            timestamp: serverTimestamp()
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, `users/${user.uid}/chatHistory`);
        }
      }
    } catch (err) {
      setMessages(prev => [...prev, { role: 'model', content: 'Er ging iets mis. Probeer het opnieuw.' }]);
    } finally {
      setTimeout(() => setIsTyping(false), 1000);
    }
  };

  return (
    <PageWrapper title="Imad 0.2">
      <div 
        ref={scrollRef}
        className="space-y-4 mb-24 px-2 overflow-y-auto max-h-[55vh] no-scrollbar scroll-smooth"
      >
        <div className="flex justify-between items-center px-2 mb-2">
           <button onClick={() => setMessages([messages[0]])} className="text-xs font-bold text-orange-600 dark:text-orange-500 ios-button bg-orange-50 dark:bg-orange-900/20 px-3 py-1.5 rounded-full">Nieuw gesprek</button>
           <p className="text-[10px] text-slate-400 uppercase tracking-widest font-black">History Active</p>
        </div>
        {messages.map((msg, i) => (
          <motion.div 
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            key={i} 
            className={cn(
              "flex flex-col max-w-[90%] space-y-1",
              msg.role === 'user' ? "ml-auto items-end" : "items-start"
            )}
          >
            <div className={cn(
              "px-4 py-3 rounded-[24px] text-sm leading-relaxed shadow-sm",
              msg.role === 'user' 
                ? "bg-orange-600 text-white rounded-tr-none" 
                : "bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-100 dark:border-slate-700 rounded-tl-none"
            )}>
              {msg.content}
            </div>
            <span className="text-[9px] text-slate-400 font-bold px-1 uppercase">{msg.role === 'user' ? 'Jij' : 'Imad 0.2'}</span>
          </motion.div>
        ))}
        {isTyping && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-start gap-2"
          >
            <div className="bg-white dark:bg-slate-800 px-4 py-3 rounded-[24px] rounded-tl-none flex gap-1 shadow-sm border border-slate-100 dark:border-slate-700">
              <span className="w-1.5 h-1.5 bg-orange-400 rounded-full animate-bounce [animation-duration:0.6s]" />
              <span className="w-1.5 h-1.5 bg-orange-400 rounded-full animate-bounce [animation-duration:0.6s] [animation-delay:0.2s]" />
              <span className="w-1.5 h-1.5 bg-orange-400 rounded-full animate-bounce [animation-duration:0.6s] [animation-delay:0.4s]" />
            </div>
          </motion.div>
        )}
      </div>

      <div className="fixed bottom-24 left-0 right-0 px-4 bg-gradient-to-t from-slate-50 dark:from-slate-950 via-slate-50 dark:via-slate-950 to-transparent pt-8 pb-4">
        <div className="max-w-md mx-auto relative mb-2">
          <input 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
            placeholder="Stel je vraag over de islam..."
            className="w-full ios-blur border border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 rounded-[30px] py-4 pl-6 pr-14 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 shadow-2xl transition-all"
          />
          <button 
            onClick={sendMessage}
            disabled={!input.trim() || isTyping}
            className="absolute right-2 top-2 w-10 h-10 bg-orange-600 text-white rounded-full flex items-center justify-center ios-button disabled:opacity-50 shadow-lg shadow-orange-300 dark:shadow-none"
          >
            <ChevronLeft className="rotate-180" size={24} />
          </button>
        </div>
      </div>
    </PageWrapper>
  );
};

const DuaList = () => {
  return (
    <PageWrapper title="Dua">
      <div className="space-y-4">
        {DUAS.map((dua) => (
          <div key={dua.id} className="ios-card p-6 space-y-4 rounded-[32px]">
            <div className="flex justify-between items-center">
               <h4 className="font-bold text-orange-800 dark:text-orange-400">{dua.title}</h4>
               <Heart size={18} className="text-rose-500 fill-current" />
            </div>
            <p className="font-arabic text-2xl text-right leading-relaxed" dir="rtl">{dua.arabic}</p>
            <div className="space-y-2 border-t border-slate-100 dark:border-slate-700 pt-4">
               <p className="text-xs italic text-slate-500 font-medium">"{dua.transliteration}"</p>
               <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">{dua.translation}</p>
            </div>
          </div>
        ))}
      </div>
    </PageWrapper>
  );
};

const Settings = () => {
  const { user, signIn, logOut, loading } = useAuth();

  return (
    <PageWrapper title="Instellingen">
       <div className="space-y-6">
          <div className="ios-card p-6 space-y-4 rounded-[32px]">
             <h3 className="font-bold text-slate-400 uppercase tracking-widest text-[10px]">Account</h3>
             {user ? (
               <div className="space-y-4">
                 <div className="flex items-center gap-4">
                    <img 
                      src={user.photoURL || ''} 
                      alt={user.displayName || ''} 
                      className="w-14 h-14 rounded-2xl bg-slate-100 object-cover shadow-sm"
                      referrerPolicy="no-referrer"
                    />
                    <div className="flex-1">
                       <p className="font-bold text-slate-900 dark:text-white">{user.displayName}</p>
                       <p className="text-xs text-slate-500">{user.email}</p>
                    </div>
                 </div>
                 <button 
                   onClick={logOut}
                   className="w-full flex items-center justify-center gap-2 bg-slate-100 dark:bg-slate-800 text-rose-500 py-3 rounded-2xl text-sm font-bold ios-button mt-2"
                 >
                   <LogOut size={18} />
                   Uitloggen
                 </button>
               </div>
             ) : (
               <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-white dark:bg-slate-800 flex items-center justify-center text-slate-400 shadow-sm">
                     <UserIcon size={28} />
                  </div>
                  <div className="flex-1">
                     <p className="font-bold text-slate-900 dark:text-white">Google Account</p>
                     <p className="text-xs text-slate-500">Log in om je voortgang op te slaan</p>
                  </div>
                  <button 
                    onClick={signIn}
                    disabled={loading}
                    className="bg-orange-600 text-white px-5 py-2.5 rounded-xl text-sm font-bold ios-button disabled:opacity-50"
                  >
                    Log in
                  </button>
               </div>
             )}
          </div>

          <div className="ios-card p-8 flex flex-col items-center text-center space-y-3 rounded-[32px]">
             <div className="w-16 h-16 bg-orange-100 dark:bg-orange-900/30 rounded-[20px] flex items-center justify-center text-orange-600 mb-2">
                <Heart className="fill-current" />
             </div>
             <h3 className="font-bold text-xl">Nur Al-Islam</h3>
             <p className="text-xs text-slate-500 font-medium">Versie 1.0.2 (Beta)</p>
             <div className="pt-2 border-t border-slate-100 dark:border-slate-800 w-full">
                <p className="text-[10px] text-slate-400 uppercase tracking-[0.2em] font-bold">Gemaakt door Mohamed Yassin</p>
                <p className="text-[9px] text-slate-300 mt-1">Powered by Imad 0.2 & Gemini AI</p>
             </div>
          </div>
       </div>
    </PageWrapper>
  );
};

// --- App Root ---

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('isDarkMode');
    return saved ? JSON.parse(saved) : false;
  });
  const [chatMessages, setChatMessages] = useState<{role: 'user' | 'model', content: string}[]>(() => {
    const saved = localStorage.getItem('chatHistory');
    return saved ? JSON.parse(saved) : [
      { role: 'model', content: 'Salam, ik ben Imad 0.2. Ik ben je islamitische AI-assistent. Hoe kan ik je vandaag helpen met je vragen over de Islam?' }
    ];
  });

  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 2500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const root = window.document.documentElement;
    if (isDarkMode) {
      root.classList.add('dark');
      document.body.classList.add('dark');
      document.body.style.backgroundColor = '#0f172a'; // Strict fallback
    } else {
      root.classList.remove('dark');
      document.body.classList.remove('dark');
      document.body.style.backgroundColor = '#f8fafc'; // Strict fallback
    }
    localStorage.setItem('isDarkMode', JSON.stringify(isDarkMode));
  }, [isDarkMode]);

  useEffect(() => {
    if (chatMessages.length > 0) {
      localStorage.setItem('chatHistory', JSON.stringify(chatMessages));
    }
  }, [chatMessages]);

  const Header = () => {
    const { user } = useAuth();

    return (
      <div className="pt-8 pb-4 px-6 flex items-center justify-between max-w-md mx-auto w-full relative z-[100]">
        <Link to="/" className="flex items-center gap-4 ios-button group cursor-pointer no-underline">
          <div className="w-14 h-14 bg-orange-600 rounded-[22px] flex items-center justify-center p-2 shadow-xl shadow-orange-200 dark:shadow-none relative group-hover:scale-105 transition-all duration-300">
            <div className="absolute inset-0 bg-white/10 group-hover:bg-white/20 transition-colors rounded-[22px]" />
            <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-white w-full h-full relative z-10">
               <path d="M15 45C15 35 35 30 50 45C65 30 85 35 85 45V75C85 85 65 80 50 70C35 80 15 85 15 75V45Z" fill="white" />
               <path d="M50 45V70" stroke="#EA580C" strokeWidth="4" strokeLinecap="round" />
               <path d="M22 50C22 45 35 43 50 50C65 43 78 45 78 50" stroke="#EA580C" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </div>
          <div className="flex flex-col items-start">
            <span className="text-3xl font-black italic tracking-tighter text-slate-900 dark:text-white leading-none">CEMI</span>
            <p className="text-[9px] uppercase tracking-[0.3em] font-black text-orange-600 dark:text-orange-500 mt-1">Nur Al-Islam</p>
          </div>
        </Link>
        {user && (
          <Link to="/settings" className="w-10 h-10 rounded-full border-2 border-white dark:border-slate-800 shadow-md overflow-hidden ios-button">
            <img src={user.photoURL || ''} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          </Link>
        )}
      </div>
    );
  };

  return (
    <AuthProvider>
      <Router>
        <AnimatePresence mode="wait">
          {showSplash ? (
            <SplashScreen key="splash" onFinish={() => setShowSplash(false)} />
          ) : (
            <div key="main" className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 selection:bg-orange-200 dark:selection:bg-orange-900">
              <Header />
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/quran" element={<QuranList />} />
                <Route path="/quran/:id" element={<QuranPageWrapper />} />
                <Route path="/chat" element={<ImadChat messages={chatMessages} setMessages={setChatMessages} />} />
                <Route path="/dua" element={<DuaList />} />
                <Route path="/settings" element={<Settings />} />
              </Routes>
              <NavBar />
            </div>
          )}
        </AnimatePresence>
      </Router>
    </AuthProvider>
  );
}

const QuranPageWrapper = () => {
  const { id } = useParams<{ id: string }>();
  return <QuranReader id={id || "1"} />;
};
