export interface Surah {
  number: number;
  name: string;
  englishName: string;
  englishNameTranslation: string;
  numberOfAyahs: number;
  revelationType: string;
}

export interface Ayah {
  number: number;
  text: string;
  numberInSurah: number;
  juz: number;
  manzil: number;
  page: number;
  ruku: number;
  hizbQuarter: number;
}

export interface SurahDetail extends Surah {
  ayahs: Ayah[];
}

const BASE_URL = "https://api.alquran.cloud/v1";

export async function getAllSurahs(): Promise<Surah[]> {
  const response = await fetch(`${BASE_URL}/surah`);
  const data = await response.json();
  return data.data;
}

export async function getSurahDetail(number: number): Promise<SurahDetail> {
  const response = await fetch(`${BASE_URL}/surah/${number}`);
  const data = await response.json();
  return data.data;
}

export function getAudioUrl(surahNumber: number): string {
  // Using a popular recitation as default (Mishary Rashid Alafasy)
  const paddedNumber = surahNumber.toString().padStart(3, '0');
  return `https://server8.mp3quran.net/afs/${paddedNumber}.mp3`;
}

// Duas service (Mocked for now with common ones as there's no major single Dua API like Quran)
export interface Dua {
  id: string;
  title: string;
  arabic: string;
  translation: string;
  transliteration: string;
  audioUrl?: string;
}

export const DUAS: Dua[] = [
  {
    id: '1',
    title: 'Dua voor het slapengaan',
    arabic: 'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا',
    translation: 'In Uw Naam, O Allah, sterf ik en leef ik.',
    transliteration: 'Bismika Allahumma amootu wa-ahya',
  },
  {
    id: '2',
    title: 'Dua bij het ontwaken',
    arabic: 'الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ',
    translation: 'Alle lof zij Allah, Die ons tot leven heeft gewekt nadat Hij aan ons de dood heeft gegeven, en tot Hem is de wederopstanding.',
    transliteration: 'Alhamdu lillahi alladhi ahyana ba\'da ma amatana wa-ilayhin-nushoor',
  },
  {
    id: '3',
    title: 'Dua voor ouders',
    arabic: 'رَّبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا',
    translation: 'Mijn Heer, schenk hun genade, zoals zij mij hebben opgevoed toen ik klein was.',
    transliteration: 'Rabbi irhamhuma kama rabbayani sagheera',
  }
];
