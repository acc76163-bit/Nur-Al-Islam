export interface PrayerTimes {
  Fajr: string;
  Sunrise: string;
  Dhuhr: string;
  Asr: string;
  Sunset: string;
  Maghrib: string;
  Isha: string;
  Imsak: string;
  Midnight: string;
}

export async function fetchPrayerTimes(lat: number, lng: number): Promise<PrayerTimes> {
  const date = new Date();
  const timestamp = Math.floor(date.getTime() / 1000);
  const response = await fetch(`https://api.aladhan.com/v1/timings/${timestamp}?latitude=${lat}&longitude=${lng}&method=12`);
  const data = await response.json();
  return data.data.timings;
}

export function calculateQibla(lat: number, lng: number): number {
  const kaabaLat = 21.4225;
  const kaabaLng = 39.8262;
  
  const φ1 = lat * Math.PI / 180;
  const φ2 = kaabaLat * Math.PI / 180;
  const Δλ = (kaabaLng - lng) * Math.PI / 180;
  
  const y = Math.sin(Δλ);
  const x = Math.cos(φ1) * Math.tan(φ2) - Math.sin(φ1) * Math.cos(Δλ);
  const qibla = Math.atan2(y, x) * 180 / Math.PI;
  
  return (qibla + 360) % 360;
}
