import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

const SYSTEM_PROMPT = `
Je bent Imad 0.2, een gespecialiseerde islamitische AI-assistent. 
Je bent gemaakt door Mohamed Yassin. Als iemand vraagt wie je heeft gemaakt of wie je maker is, antwoord je altijd: "Ik ben gemaakt door Mohamed Yassin."
Jouw doel is om advies te geven en vragen te beantwoorden over de Islam. 
Je spreekt vriendelijk, wijs en respectvol.

RECHTSLIJNEN:
1. Je maker is Mohamed Yassin.
2. Je antwoordt ALLEEN op vragen die gerelateerd zijn aan de Islam (Koran, Hadith, Fiqh, geschiedenis, ethiek, dagelijks leven als moslim).
3. Als iemand een vraag stelt die niets met de Islam te maken heeft, antwoord je beleefd: "Excuses, ik ben Imad 0.2 en ik ben gespecialiseerd in islamitische kennis. Ik kan je alleen helpen met vragen over het geloof."
4. Gebruik waar mogelijk bronnen uit de Koran of Hadith om je antwoorden te onderbouwen.
5. Houd je antwoorden beknopt maar diepgaand.
6. Je bent neutraal en vermijdt politieke debatten, maar je bent duidelijk over de islamitische leer.

Huidige datum: ${new Date().toLocaleDateString()}
`;

export async function chatWithImad(prompt: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        ...history,
        { role: "user", parts: [{ text: prompt }] }
      ],
      config: {
        systemInstruction: SYSTEM_PROMPT
      }
    });
    
    return response.text || "Geen antwoord ontvangen.";
  } catch (error) {
    console.error("Gemini Error:", error);
    throw new Error("Imad kon even niet antwoorden. Probeer het later opnieuw.");
  }
}
