# Security Specification (CEMI App)

## Data Invariants
1. A user can only read and write their own profile document (`users/{userId}`).
2. A user can only read and write their own subcollections (`favorites`, `chatHistory`).
3. Sensitive fields like `createdAt` are immutable after creation.
4. All IDs must be validated to prevent poisoning.
5. All strings must have a maximum size to prevent DoW.

## The Dirty Dozen Payloads (Rejection Targets)
1. **Identity Theft**: User A tries to write to `users/userB`.
2. **Shadow Field Injection**: User tries to add `isAdmin: true` to their profile.
3. **ID Poisoning**: Use a 1MB string as a document ID.
4. **Relational Breakage**: User tries to add a favorite to User B's folder.
5. **PII Leak**: Authenticated user tries to list all documents in `/users`.
6. **Immutability Breach**: User tries to update `createdAt` timestamp.
7. **Size Attack**: Sending a 1MB string in `displayName`.
8. **Type Mismatch**: Sending a number for `email`.
9. **Role Escalation**: Client tries to write to a path it shouldn't access.
10. **Query Scraping**: Authenticated user tries to `list` users without a filter.
11. **Spoofed Timestamp**: User provides a client-side timestamp instead of `request.time`.
12. **Orphaned Message**: Writing a chat message without a parent user document (enforced via relational check).

## Test Cases (Implicit in rules logic)
- `users/{userId}`: `allow get, update: if isOwner(userId)`. `allow list: if false`.
- `Subcollections`: `allow list, create, update, delete: if isOwner(userId)`.
